// Office Dashboard — local server
// Plain Node.js, no external dependencies. Run with: node server.js
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
const STORE_FILE = path.join(DATA_DIR, 'store.json');

// ---------- simple JSON key-value store, persisted to disk ----------
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(STORE_FILE)) fs.writeFileSync(STORE_FILE, '{}', 'utf8');

function loadStore() {
  try {
    return JSON.parse(fs.readFileSync(STORE_FILE, 'utf8') || '{}');
  } catch (e) {
    console.error('Failed to read store.json, starting fresh:', e.message);
    return {};
  }
}
function saveStore(store) {
  fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), 'utf8');
}

// ---------- static file serving ----------
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
};

function serveStatic(req, res, urlPath) {
  let filePath = urlPath === '/' ? '/index.html' : urlPath;
  filePath = path.join(PUBLIC_DIR, decodeURIComponent(filePath));

  // prevent path traversal outside PUBLIC_DIR
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('404 Not Found');
      return;
    }
    const ext = path.extname(filePath);
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(content);
  });
}

// ---------- request body helper ----------
function readBody(req) {
  return new Promise((resolve, reject) => {
    let chunks = '';
    req.on('data', (c) => (chunks += c));
    req.on('end', () => resolve(chunks));
    req.on('error', reject);
  });
}

function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

// ---------- API: /api/storage ----------
async function handleApi(req, res, parsedUrl) {
  const pathname = parsedUrl.pathname;

  // GET /api/storage?prefix=xxx  -> list keys
  if (pathname === '/api/storage' && req.method === 'GET') {
    const prefix = parsedUrl.searchParams.get('prefix') || '';
    const store = loadStore();
    const keys = Object.keys(store).filter((k) => k.startsWith(prefix));
    sendJson(res, 200, { keys, prefix });
    return;
  }

  // /api/storage/:key
  const match = pathname.match(/^\/api\/storage\/(.+)$/);
  if (match) {
    const key = decodeURIComponent(match[1]);

    if (req.method === 'GET') {
      const store = loadStore();
      if (!(key in store)) {
        sendJson(res, 404, { error: 'not found' });
        return;
      }
      sendJson(res, 200, { key, value: store[key] });
      return;
    }

    if (req.method === 'PUT') {
      try {
        const raw = await readBody(req);
        const body = JSON.parse(raw || '{}');
        const store = loadStore();
        store[key] = body.value;
        saveStore(store);
        sendJson(res, 200, { key, value: store[key] });
      } catch (e) {
        sendJson(res, 400, { error: 'invalid body' });
      }
      return;
    }

    if (req.method === 'DELETE') {
      const store = loadStore();
      const existed = key in store;
      delete store[key];
      saveStore(store);
      sendJson(res, 200, { key, deleted: existed });
      return;
    }
  }

  sendJson(res, 404, { error: 'not found' });
}

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host}`);

  if (parsedUrl.pathname.startsWith('/api/')) {
    try {
      await handleApi(req, res, parsedUrl);
    } catch (e) {
      console.error(e);
      sendJson(res, 500, { error: 'server error' });
    }
    return;
  }

  serveStatic(req, res, parsedUrl.pathname);
});

server.listen(PORT, () => {
  console.log(`\n✨ Office Dashboard is running!`);
  console.log(`   Open http://localhost:${PORT} in your browser\n`);
  console.log(`   Data is saved to: ${STORE_FILE}\n`);
});
